const express = require('express');
const bodyParser = require('body-parser');
const cart = require('./cart');

const app = express();
const port = 3000;

// Middleware
app.use(bodyParser.json());

// Add item to cart 
app.post('/addItem/:order_id', (req, res) => {
    const { order_id } = req.params;
    const { menu_item_id, name, price, quantity, availability } = req.body;
    cart.addItem(order_id, menu_item_id, name, price, quantity, availability, (err) => {
        if (err) {
            res.status(500).send(`Error adding item to cart: ${err.message}`);
        } else {
            res.send('Item added to cart.');
        }
    });
});

// Update item quantity 
app.put('/updateQuantity/:order_id', (req, res) => {
    const { order_id} = req.params;
    const { menu_item_id, quantity } = req.body;
    cart.updateQuantity(order_id, menu_item_id, quantity, (err) => {
        if (err) {
            res.status(500).send(`Error updating item quantity: ${err.message}`);
        } else {
            res.send(`Item quantity updated to ${quantity}`);
        }
    });
});

// Increment item quantity 
app.put('/incItem/:order_id', (req, res) => {
    const { order_id} = req.params;
    const { menu_item_id } = req.body;
    cart.incItem(order_id, menu_item_id, (err) => {
        if (err) {
            res.status(500).send(`Error incrementing item quantity: ${err.message}`);
        } else {
            res.send('Item quantity adjusted.');
        }
    });
});

// Increment item quantity 
app.put('/decItem/:order_id', (req, res) => {
    const { order_id} = req.params;
    const { menu_item_id } = req.body;
    cart.decItem(order_id, menu_item_id, (err) => {
        if (err) {
            res.status(500).send(`Error decrementing item quantity: ${err.message}`);
        } else {
            res.send('Item quantity adjusted.');
        }
    });
});

// Remove item from cart 
app.delete('/removeItem/:order_id', (req, res) => {
    const { order_id } = req.params;
    const {menu_item_id} = req.body;
    cart.removeItem(order_id, menu_item_id, (err) => {
        if (err) {
            res.status(500).send(`Error removing item from cart: ${err.message}`);
        } else {
            res.send('Item removed from cart.');
        }
    });
});

// Clear cart 
app.delete('/clearCart/:order_id', (req, res) => {
    const { order_id } = req.params;
    cart.clearCart(order_id, (err) => {
        if (err) {
            res.status(500).send(`Error clearing cart: ${err.message}`);
        } else {
            res.send('Cart cleared.');
        }
    });
});

// Get total price x
app.get('/getTotalPrice/:order_id', (req, res) => {
    const { order_id } = req.params;
    cart.getTotalPrice(order_id, (err, totalPrice) => {
        if (err) {
            res.status(500).send(`Error getting total price: ${err.message}`);
        } else {
            res.send(`Total Price: $${totalPrice}`);
        }
    });
});

// Get item quantity 
app.get('/getItemQuantity/:order_id', (req, res) => {
    const { order_id } = req.params;
    const { menu_item_id} = req.body;
    cart.getItemQuantity(order_id, menu_item_id, (err, itemQuant) => {
        if (err) {
            res.status(500).send(`Error getting total price: ${err.message}`);
        } else {
            res.send(`Amount of Item: ${itemQuant}`);
        }
    });
});

// Get item price 
app.get('/getItemPrice/:order_id', (req, res) => {
    const { order_id } = req.params;
    const { menu_item_id} = req.body;
    cart.getItemPrice(order_id, menu_item_id, (err, itemPrice) => {
        if (err) {
            res.status(500).send(`Error getting total price: ${err.message}`);
        } else {
            res.send(`Price of Single Item: $${itemPrice}`);
        }
    });
});

// Get item price 
app.get('/getItemTotal/:order_id', (req, res) => {
    const { order_id } = req.params;
    const { menu_item_id} = req.body;
    cart.getItemTotal(order_id, menu_item_id, (err, itemPrice) => {
        if (err) {
            res.status(500).send(`Error getting total price: ${err.message}`);
        } else {
            res.send(`Total Price of this Item: $${itemPrice}`);
        }
    });
});

//Review Cart
app.get('/reviewCart/:order_id', (req, res) => {
    const { order_id } = req.params;

    cart.reviewCart(order_id, (err, cartItems) => {
        if (err) {
            console.error('Error reviewing cart:', err);
            res.status(500).send('Error reviewing cart');
        } else {
            if (cartItems.length === 0) {
                res.send('Cart is empty');
            } else {
                res.json(cartItems);
            }
        }
    });
});

// Checkout route
app.post('/checkout/:order_id', (req, res) => {
    const { method } = req.body;
    cart.checkout(req, res,method);
});

// Start server
app.listen(port, () => {
    console.log(`Server running on port ${port}`);
});