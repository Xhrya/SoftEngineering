const cartModule = require('../src/cart');

describe('Cart Module', () => {
    // Test case for adding an item to the cart
    it('should add an item to the cart', (done) => {
        cartModule.addItem(1, 'item_id', 'Item Name', 10.99, 2, true, (err) => {
            expect(err).toBeNull();
            done();
        });
    });

    // Test case for removing an item from the cart
    it('should remove an item from the cart', (done) => {
        cartModule.removeItem(1, 'item_id', (err) => {
            expect(err).toBeNull();
            done();
        });
    });

    // Test case for clearing the cart
    it('should clear the cart', (done) => {
        cartModule.clearCart(1, (err) => {
            expect(err).toBeNull();
            done();
        });
    });

    // Test case for updating the quantity of an item
    it('should update the quantity of an item in the cart', (done) => {
        cartModule.updateQuantity(1, 'item_id', 5, (err) => {
            expect(err).toBeNull();
            done();
        });
    });

    // Test case for incrementing the quantity of an item
    it('should increase the quantity of an item in the cart by 1', (done) => {
        cartModule.incItem(1, 'item_id', (err) => {
            expect(err).toBeNull();
            done();
        });
    });

    // Test case for decrementing the quantity of an item
    it('should decrease the quantity of an item in the cart by 1', (done) => {
        cartModule.decItem(1, 'item_id', (err) => {
            expect(err).toBeNull();
            done();
        });
    });

    // Test case for getting the price of an item
    it('should get the price of an item in the cart', (done) => {
        cartModule.getItemPrice(1, 'item_id', (err, price) => {
            expect(err).toBeNull();
            expect(price).toEqual(10.99);
            done();
        });
    });

    // Test case for getting the quantity of an item
    it('should get the quantity of an item in the cart', (done) => {
        cartModule.getItemQuantity(1, 'item_id', (err, quantity) => {
            expect(err).toBeNull();
            expect(quantity).toEqual(5); // Assuming the quantity was updated in the previous test case
            done();
        });
    });

    // Test case for getting the total price of items in the cart
    it('should get the total price of items in the cart', (done) => {
        cartModule.getTotalPrice(1, (err, totalPrice) => {
            expect(err).toBeNull();
            expect(totalPrice).toEqual(54.95); // Assuming the price is correct based on previous operations
            done();
        });
    });

    // Test case for getting the total price of a specific item in the cart
    it('should get the total price of a specific item in the cart', (done) => {
        cartModule.getItemTotal(1, 'item_id', (err, totalPrice) => {
            expect(err).toBeNull();
            expect(totalPrice).toEqual(54.95); // Assuming the price is correct based on previous operations
            done();
        });
    });

    // Test case for reviewing the cart
    it('should review the cart', (done) => {
        cartModule.reviewCart(1, (err, cartItems) => {
            expect(err).toBeNull();
            expect(cartItems).toEqual([{ menu_item_id: 'item_id', name: 'Item Name', quantity: '5', price: '$10.99', 'total price for item': '$54.95' }]);
            done();
        });
    });

    // Test case for checkout
    it('should complete the checkout process', () => {
        // Mock request and response objects
        const req = {};
        const res = {};
        const method = ''; // Assuming there's no specific method needed for the test

        // Spy on console.log to ensure it's called
        spyOn(console, 'log');

        // Call the checkout function
        cartModule.checkout(req, res, method);

        // Expect console.log to have been called with the appropriate message
        expect(console.log).toHaveBeenCalledWith('Thank you for your purchase!');
    });
});
