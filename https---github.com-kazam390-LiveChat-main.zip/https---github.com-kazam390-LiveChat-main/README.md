The code is run on a server https://render.com/
Make a free account
Link the repository
Setting:
Branch: Main
Root Directory: Server
Start Command: npm Start
